package com.navin.android.weatherup;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import com.navin.android.weatherup.data.WeatherInfo;
import com.navin.android.weatherup.data.WeatherRepository;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private RecyclerView mForecastRecyclerView;
    private ForecastAdapter mForecastAdapter;
    private ProgressBar mLoadingIndicator;
    private WeatherRepository mWeatherRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mForecastRecyclerView = findViewById(R.id.rv_weather_forecast);
        mLoadingIndicator = findViewById(R.id.pb_loading_weather);

        mForecastAdapter = new ForecastAdapter(this);
        mForecastRecyclerView.setAdapter(mForecastAdapter);
        mForecastRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mForecastRecyclerView.setHasFixedSize(true);

        mWeatherRepository = new WeatherRepository(getApplication());
        getWeatherData();

    }

    private void getWeatherData() {
        LiveData<List<WeatherInfo>> weatherLiveData = mWeatherRepository.getmWeatherInfoList();

        weatherLiveData.observe(this, new Observer<List<WeatherInfo>>() {
            @Override
            public void onChanged(@Nullable List<WeatherInfo> weatherInfoList) {
                mForecastAdapter.setWeatherData(weatherInfoList);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if(itemId == R.id.action_refresh){
            mLoadingIndicator.setVisibility(View.VISIBLE);
            mWeatherRepository.insertWeatherDataFromApi();
            getWeatherData();
            mLoadingIndicator.setVisibility(View.INVISIBLE);
        }
        return super.onOptionsItemSelected(item);
    }
}
